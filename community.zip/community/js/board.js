// 커뮤니티 게시판 카테고리 관리 JavaScript 파일

document.addEventListener('DOMContentLoaded', function() {
  // 로그인 상태 확인
  checkLoginStatus();

  // URL 파라미터에서 카테고리 정보 가져오기
  const urlParams = new URLSearchParams(window.location.search);
  let category = urlParams.get('category');
  let section = urlParams.get('section') || 'common';
  const page = parseInt(urlParams.get('page') || '1');
  
  // URL에 category 파라미터가 없는 경우 자유게시판으로 설정
  if (!category) {
    category = 'free';
    // URL에 자유게시판 파라미터 추가
    const url = new URL(window.location);
    url.searchParams.set('category', 'free');
    window.history.replaceState({}, '', url);
  }
  
  // 특별 페이지에서 카테고리 버튼 표시/숨김 처리
  handleSpecialCategories(category);
  
  // 섹션에 따라 카테고리 버튼 업데이트
  updateCategoryButtonsBySection(section);
  
  // 현재 카테고리에 맞는 게시물 표시
  updateBoardList(category, section, page);
  
  // 게시판 제목 업데이트
  // 자유게시판인 경우 제목 변경
  if (category === 'free') {
    document.querySelector('.board-header h2').textContent = '자유게시판';
    document.querySelector('.board-header p').textContent = '자유롭게 의견을 나누는 공간입니다.';
  } else {
    updateBoardTitle(category, section);
  }
  
  // 메인 메뉴 이벤트 리스너 등록
  initMainMenuListeners();
  
  // 페이지네이션 이벤트 리스너 등록
  initPagination(category, section);
  
  // 글쓰기 버튼 이벤트 리스너 등록
  initWriteButton();
});

// 로그인 상태 확인 함수
function checkLoginStatus() {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  const loginRequiredElement = document.getElementById('login-required');
  const boardContentElement = document.getElementById('board-content');
  
  if (isLoggedIn) {
    // 로그인한 경우 게시판 컨텐츠 표시
    if (loginRequiredElement) loginRequiredElement.style.display = 'none';
    if (boardContentElement) boardContentElement.style.display = 'block';
  } else {
    // 로그인하지 않은 경우 로그인 필요 메시지 표시
    if (loginRequiredElement) loginRequiredElement.style.display = 'block';
    if (boardContentElement) boardContentElement.style.display = 'none';
  }
}

// 특별 카테고리 처리 (자유게시판, 공지사항, 구매후기)
function handleSpecialCategories(category) {
  const boardCategory = document.querySelector('.board-category');
  if (!boardCategory) return;
  
  // 자유게시판이나 공지사항의 경우 카테고리 버튼 영역 숨김
  if (category === 'free' || category === 'notice') {
    boardCategory.style.display = 'none';
  } 
  // 구매후기인 경우 야구용품 카테고리로 변경
  else if (category === 'review') {
    let categoryButtonsHTML = '';
    
    const reviewCategories = [
      { text: '전체상품', value: 'all-products' },
      { text: '글러브', value: 'gloves' },
      { text: '배트', value: 'bats' },
      { text: '유니폼', value: 'uniforms' },
      { text: '스파이크', value: 'spikes' },
      { text: '보호장비', value: 'protection' },
      { text: '가방/용품', value: 'bags' }
    ];
    
    reviewCategories.forEach(cat => {
      categoryButtonsHTML += `<a href="#" class="category-btn" data-category="${cat.value}">${cat.text}</a>`;
    });
    
    // HTML 삽입
    boardCategory.innerHTML = categoryButtonsHTML;
    boardCategory.style.display = 'flex';
    
    // 첫 번째 버튼 활성화
    const firstButton = boardCategory.querySelector('.category-btn');
    if (firstButton) {
      firstButton.classList.add('active');
    }
    
    // 카테고리 버튼 이벤트 리스너 등록
    initProductCategoryButtons();
  } else {
    boardCategory.style.display = 'flex';
  }
}

// 구매후기 카테고리의 이벤트 리스너 등록
function initProductCategoryButtons() {
  const categoryButtons = document.querySelectorAll('.category-btn');
  
  categoryButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const productCategory = this.getAttribute('data-category');
      
      // URL 업데이트
      const url = new URL(window.location);
      url.searchParams.set('product', productCategory);
      url.searchParams.delete('page'); // 페이지 초기화
      window.history.pushState({}, '', url);
      
      // 카테고리 버튼 활성화 상태 업데이트
      categoryButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // 여기서 제품 카테고리에 따른 게시물 필터링 처리
      filterProductReviews(productCategory);
    });
  });
}

// 제품 카테고리별 리뷰 필터링
function filterProductReviews(productCategory) {
  const boardTitle = document.querySelector('.board-header h2');
  const boardDesc = document.querySelector('.board-header p');
  const tableRows = document.querySelectorAll('.board-table tbody tr:not(.notice)');
  
  // 제목 변경
  if (boardTitle) {
    if (productCategory === 'all-products') {
      boardTitle.textContent = '구매후기';
      if (boardDesc) {
        boardDesc.textContent = '다양한 야구용품의 구매후기를 확인하세요.';
      }
    } else {
      let categoryText = '구매후기';
      
      // 제품 카테고리별 이름
      switch(productCategory) {
        case 'gloves': categoryText = '글러브 구매후기'; break;
        case 'bats': categoryText = '배트 구매후기'; break;
        case 'uniforms': categoryText = '유니폼 구매후기'; break;
        case 'spikes': categoryText = '스파이크 구매후기'; break;
        case 'protection': categoryText = '보호장비 구매후기'; break;
        case 'bags': categoryText = '가방/용품 구매후기'; break;
      }
      
      boardTitle.textContent = categoryText;
      if (boardDesc) {
        boardDesc.textContent = `${categoryText}를 확인하고 구매에 참고하세요.`;
      }
    }
  }
  
  // 실제 서비스에서는 서버에서 데이터를 가져와야 하지만
  // 현재는 기존 데이터에서 시뮬레이션만 진행
  // 모든 행을 숨기고 "해당 상품 리뷰가 없습니다" 메시지 표시
  tableRows.forEach(row => {
    row.style.display = 'none';
  });
  
  // 공지사항 처리
  const noticeRows = document.querySelectorAll('.board-table tbody tr.notice');
  noticeRows.forEach(row => {
    row.style.display = 'none';
  });
  
  // 게시물이 없는 경우 메시지 표시
  let noPostsRow = document.querySelector('.no-posts-row');
  if (!noPostsRow) {
    const tbody = document.querySelector('.board-table tbody');
    const newRow = document.createElement('tr');
    newRow.className = 'no-posts-row';
    
    newRow.innerHTML = `<td colspan="6" style="text-align: center; padding: 40px 0;">
      ${productCategory === 'all-products' ? '등록된 구매후기가 없습니다.' : '해당 상품의 구매후기가 없습니다.'}
    </td>`;
    tbody.appendChild(newRow);
  } else {
    noPostsRow.style.display = '';
    const messageCell = noPostsRow.querySelector('td');
    if (messageCell) {
      messageCell.textContent = productCategory === 'all-products' ? '등록된 구매후기가 없습니다.' : '해당 상품의 구매후기가 없습니다.';
    }
  }
}

// 메인 메뉴 항목 클릭 이벤트 리스너 등록
function initMainMenuListeners() {
  const mainMenuItems = document.querySelectorAll('.nav-menu > li > a');
  
  mainMenuItems.forEach(item => {
    // 이미 href에 URL 파라미터가 있는 항목은 건너뛰기
    if (item.getAttribute('href').includes('category=')) {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        const categoryParam = new URLSearchParams(href.substring(href.indexOf('?'))).get('category');
        
        if (categoryParam) {
          // URL 업데이트
          const url = new URL(window.location);
          url.searchParams.set('category', categoryParam);
          url.searchParams.delete('section'); // section 초기화
          url.searchParams.delete('page'); // 페이지 초기화
          window.history.pushState({}, '', url);
          
          // 특별 카테고리 처리
          handleSpecialCategories(categoryParam);
          
          // 게시판 제목 및 컨텐츠 업데이트
          if (categoryParam === 'free') {
            document.querySelector('.board-header h2').textContent = '자유게시판';
            document.querySelector('.board-header p').textContent = '자유롭게 의견을 나누는 공간입니다.';
          } else if (categoryParam === 'notice') {
            document.querySelector('.board-header h2').textContent = '공지사항';
            document.querySelector('.board-header p').textContent = '중요한 공지사항을 확인하세요.';
          } else if (categoryParam === 'review') {
            document.querySelector('.board-header h2').textContent = '구매후기';
            document.querySelector('.board-header p').textContent = '다양한 야구용품의 구매후기를 확인하세요.';
          }
          
          // 게시물 업데이트
          updateBoardList(categoryParam, 'common', 1);
        }
      });
      return;
    }
    
    // data-section 속성이 있는 메뉴 항목에만 이벤트 리스너 추가
    const sectionValue = item.getAttribute('data-section');
    if (sectionValue) {
      item.addEventListener('click', function(e) {
        e.preventDefault();
        
        // URL 업데이트
        const url = new URL(window.location);
        url.searchParams.set('section', sectionValue);
        url.searchParams.delete('category'); // 카테고리 초기화
        url.searchParams.delete('page'); // 페이지 초기화
        window.history.pushState({}, '', url);
        
        // 특별 카테고리 초기화: 섹션 변경 시 카테고리 버튼 다시 표시
        const boardCategory = document.querySelector('.board-category');
        if (boardCategory) boardCategory.style.display = 'flex';
        
        // 카테고리 버튼 업데이트
        updateCategoryButtonsBySection(sectionValue);
        
        // 게시판 제목 업데이트
        updateBoardTitle('all', sectionValue);
        
        // 게시물 목록 업데이트
        updateBoardList('all', sectionValue, 1);
      });
    }
  });
}

// 섹션별 카테고리 버튼 업데이트
function updateCategoryButtonsBySection(section) {
  const boardCategory = document.querySelector('.board-category');
  if (!boardCategory) return;
  
  // 섹션별 카테고리 정의
  const categories = getSectionCategories(section);
  
  // 카테고리 버튼 HTML 생성
  let categoryButtonsHTML = '';
  categories.forEach(cat => {
    categoryButtonsHTML += `<a href="#" class="category-btn" data-category="${cat.value}">${cat.text}</a>`;
  });
  
  // HTML 삽입
  boardCategory.innerHTML = categoryButtonsHTML;
  
  // 첫 번째 버튼 활성화
  const firstButton = boardCategory.querySelector('.category-btn');
  if (firstButton) {
    firstButton.classList.add('active');
  }
  
  // 카테고리 버튼 이벤트 리스너 등록
  initCategoryButtons();
}

// 섹션별 카테고리 목록 반환
function getSectionCategories(section) {
  switch(section) {
    case 'kbo':
      return [
        { text: '전체팀', value: 'all' },
        { text: '두산', value: 'doosan' },
        { text: '롯데', value: 'lotte' },
        { text: '삼성', value: 'samsung' },
        { text: 'KIA', value: 'kia' },
        { text: 'NC', value: 'nc' },
        { text: 'KT', value: 'kt' },
        { text: 'LG', value: 'lg' },
        { text: 'SSG', value: 'ssg' },
        { text: '키움', value: 'kiwoom' },
        { text: '한화', value: 'hanwha' }
      ];
    case 'pro':
      return [
        { text: '전체보기', value: 'all' },
        { text: 'NPB', value: 'npb' },
        { text: 'MLB', value: 'mlb' },
        { text: '요미우리', value: 'yomiuri' },
        { text: '한신', value: 'hanshin' },
        { text: '양키스', value: 'yankees' },
        { text: '레드삭스', value: 'redsox' },
        { text: '다저스', value: 'dodgers' }
      ];
    case 'national':
      return [
        { text: '전체국가', value: 'all' },
        { text: '한국', value: 'korea' },
        { text: '미국', value: 'usa' },
        { text: '일본', value: 'japan' },
        { text: '대만', value: 'taiwan' },
        { text: '쿠바', value: 'cuba' },
        { text: '도미니카', value: 'dominican' }
      ];
    case 'amateur':
      return [
        { text: '전체', value: 'all' },
        { text: '지역별', value: 'region' },
        { text: '서울', value: 'seoul' },
        { text: '경기', value: 'gyeonggi' },
        { text: '인천', value: 'incheon' },
        { text: '부산', value: 'busan' },
        { text: '대구', value: 'daegu' },
        { text: '기타지역', value: 'other' }
      ];
    case 'highschool':
      return [
        { text: '전체', value: 'all' },
        { text: '청룡기', value: 'cheongryong' },
        { text: '황금사자기', value: 'goldlion' },
        { text: '봉황대기', value: 'phoenix' },
        { text: '대통령배', value: 'president' },
        { text: '지역별', value: 'region' }
      ];
    default:
      return [
        { text: '전체글', value: 'all' },
        { text: '공지사항', value: 'notice' },
        { text: '자유게시판', value: 'free' },
        { text: '구매후기', value: 'review' },
        { text: '야구팁', value: 'tips' },
        { text: 'FAQ', value: 'faq' }
      ];
  }
}

// 카테고리 버튼 초기화 및 이벤트 리스너 등록
function initCategoryButtons() {
  const categoryButtons = document.querySelectorAll('.category-btn');
  const urlParams = new URLSearchParams(window.location.search);
  const currentCategory = urlParams.get('category') || 'all';
  
  categoryButtons.forEach(button => {
    // 현재 카테고리에 active 클래스 추가
    const categoryValue = button.getAttribute('data-category');
    if (categoryValue === currentCategory) {
      button.classList.add('active');
    } else {
      button.classList.remove('active');
    }
    
    // 클릭 이벤트 리스너 추가
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const category = this.getAttribute('data-category');
      const section = urlParams.get('section') || 'common';
      
      // URL 업데이트 (페이지 새로고침 없이)
      const url = new URL(window.location);
      url.searchParams.set('category', category);
      window.history.pushState({}, '', url);
      
      // 카테고리 버튼 활성화 상태 업데이트
      categoryButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // 게시판 목록 및 제목 업데이트
      updateBoardList(category, section);
      updateBoardTitle(category, section);
    });
  });
}

// 게시판 제목 업데이트
function updateBoardTitle(category, section) {
  const boardTitle = document.querySelector('.board-header h2');
  const boardDesc = document.querySelector('.board-header p');
  if (!boardTitle) return;
  
  // 섹션 이름 가져오기
  const sectionName = getSectionName(section);
  
  // 현재 카테고리 이름 가져오기
  let categoryText = '';
  const categories = getSectionCategories(section);
  const categoryObj = categories.find(c => c.value === category);
  if (categoryObj) {
    categoryText = categoryObj.text;
  }
  
  // 제목 업데이트
  if (category === 'all') {
    if (section === 'common') {
      boardTitle.textContent = 'HittoStore 커뮤니티';
      if (boardDesc) {
        boardDesc.textContent = '야구를 사랑하는 사람들의 이야기 공간입니다. 자유롭게 소통하세요!';
      }
    } else {
      boardTitle.textContent = `${sectionName} 커뮤니티`;
      if (boardDesc) {
        boardDesc.textContent = `${sectionName} 관련 소식과 정보를 공유하는 공간입니다.`;
      }
    }
  } else {
    boardTitle.textContent = `${sectionName} - ${categoryText}`;
    if (boardDesc) {
      boardDesc.textContent = `${sectionName}의 ${categoryText} 관련 소식과 정보를 공유하는 공간입니다.`;
    }
  }
}

// 섹션 이름 가져오기
function getSectionName(section) {
  switch(section) {
    case 'kbo': return 'KBO';
    case 'pro': return 'NPB/MLB';
    case 'national': return '국가대표';
    case 'amateur': return '사회인야구';
    case 'highschool': return '고교야구';
    default: return 'HittoStore 커뮤니티';
  }
}

// 카테고리에 맞는 게시물 필터링 및 표시
function updateBoardList(category, section, currentPage = 1) {
  const POSTS_PER_PAGE = 10; // 페이지당 게시글 수
  const tableRows = document.querySelectorAll('.board-table tbody tr:not(.notice):not(.no-posts-row)');
  
  // 공지사항 처리
  const noticeRows = document.querySelectorAll('.board-table tbody tr.notice');
  noticeRows.forEach(row => {
    if ((section === 'common' && (category === 'all' || category === 'notice')) || 
        (section !== 'common' && category === 'all')) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });
  
  // 먼저 카테고리에 맞는 게시물 필터링
  const filteredRows = [];
  tableRows.forEach(row => {
    const rowSection = row.dataset.section || 'common';
    const rowCategory = row.dataset.category || 'all';
    
    // 카테고리 필터링 로직
    if ((rowSection === section) && (category === 'all' || rowCategory === category)) {
      filteredRows.push(row);
    }
  });
  
  // 필터링된 게시물 중 현재 페이지에 해당하는 게시물만 표시
  const startIndex = (currentPage - 1) * POSTS_PER_PAGE;
  const endIndex = startIndex + POSTS_PER_PAGE;
  
  // 모든 게시물 먼저 숨김
  tableRows.forEach(row => {
    row.style.display = 'none';
  });
  
  // 현재 페이지에 해당하는 게시물만 표시
  for (let i = 0; i < filteredRows.length; i++) {
    if (i >= startIndex && i < endIndex) {
      filteredRows[i].style.display = '';
    }
  }
  
  // 게시물이 없는 경우 메시지 표시
  const noPostsRow = document.querySelector('.no-posts-row');
  if (noPostsRow) {
    if (filteredRows.length === 0) {
      // 메시지 내용 설정
      const messageCell = noPostsRow.querySelector('td');
      if (messageCell) {
        if (section !== 'common') {
          const sectionName = getSectionName(section);
          const categories = getSectionCategories(section);
          const categoryObj = categories.find(c => c.value === category);
          const categoryText = categoryObj ? categoryObj.text : '';
          
          messageCell.textContent = `${sectionName}${categoryText !== '전체' ? ' - ' + categoryText : ''} 게시물이 없습니다.`;
        } else if (category === 'free') {
          messageCell.textContent = '자유게시판에 게시물이 없습니다. 첫 게시물을 작성해보세요!';
        } else if (category === 'notice') {
          // 공지사항은 기본 공지글 2개가 있으므로 일반적으로 표시되지 않습니다
          messageCell.textContent = '추가 공지사항이 없습니다.';
        } else if (category === 'review') {
          messageCell.textContent = '등록된 구매후기가 없습니다. 제품을 구매하고 후기를 남겨보세요!';
        } else {
          messageCell.textContent = '해당 카테고리에 게시물이 없습니다.';
        }
      }
      
      // '게시물 없음' 메시지 표시
      noPostsRow.style.display = '';
    } else {
      // 게시물이 있으면 '게시물 없음' 메시지 숨김
      noPostsRow.style.display = 'none';
    }
  }
  
  // 페이지네이션 UI 업데이트
  const totalPages = filteredRows.length > 0 ? Math.ceil(filteredRows.length / POSTS_PER_PAGE) : 1;
  updatePaginationUI(currentPage, totalPages, category, section);
  
  return filteredRows.length > 0;
}

// 페이지네이션 UI 업데이트
function updatePaginationUI(currentPage, totalPages, category, section) {
  const pagination = document.querySelector('.pagination');
  if (!pagination) return;
  
  let paginationHTML = '';
  
  // 이전 페이지 버튼
  paginationHTML += `<a href="#" class="page-btn prev ${currentPage <= 1 ? 'disabled' : ''}" 
                      data-page="${currentPage - 1}"><i class="fas fa-chevron-left"></i></a>`;
  
  // 페이지 번호
  const startPage = Math.max(1, currentPage - 2);
  const endPage = Math.min(totalPages, startPage + 4);
  
  for (let i = startPage; i <= endPage; i++) {
    paginationHTML += `<a href="#" class="page-num ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</a>`;
  }
  
  // 다음 페이지 버튼
  paginationHTML += `<a href="#" class="page-btn next ${currentPage >= totalPages ? 'disabled' : ''}" 
                      data-page="${currentPage + 1}"><i class="fas fa-chevron-right"></i></a>`;
  
  pagination.innerHTML = paginationHTML;
  
  // 페이지네이션 이벤트 리스너 등록
  initPagination(category, section);
}

// 페이지네이션 이벤트 리스너 등록
function initPagination(category, section) {
  const pageLinks = document.querySelectorAll('.pagination a');
  
  pageLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      // 비활성화된 버튼은 클릭 무시
      if (this.classList.contains('disabled')) {
        return;
      }
      
      const page = parseInt(this.getAttribute('data-page'));
      
      // URL 업데이트
      const url = new URL(window.location);
      url.searchParams.set('page', page);
      window.history.pushState({}, '', url);
      
      // 게시물 목록 업데이트
      updateBoardList(category, section, page);
      
      // 스크롤을 게시판 상단으로 이동
      const boardHeader = document.querySelector('.board-header');
      if (boardHeader) {
        boardHeader.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// 게시글 상세보기 페이지 이동 (URL 매개변수 사용)
function viewPost(postId, category) {
  // 현재 URL에 post_id와 category 파라미터 추가
  const url = new URL(window.location);
  url.searchParams.set('post_id', postId);
  url.searchParams.set('view', 'detail');
  if (category) {
    url.searchParams.set('category', category);
  }
  window.history.pushState({}, '', url);
  
  // 여기에 게시글 상세 내용을 불러오는 코드 추가 (실제 구현에서는 서버에서 데이터 가져오기)
  fetchPostDetail(postId);
}

// 게시글 상세 내용 불러오기 (예시 함수)
function fetchPostDetail(postId) {
  // 실제 구현에서는 서버에서 데이터 가져오기
  // 여기서는 간단한 예시로 구현
  
  // 게시판 목록 숨기기
  const boardList = document.querySelector('.board-list');
  boardList.style.display = 'none';
  
  // 게시글 상세 컨테이너 생성 또는 표시
  let postDetail = document.querySelector('.post-detail');
  if (!postDetail) {
    postDetail = document.createElement('div');
    postDetail.className = 'post-detail';
    boardList.parentNode.insertBefore(postDetail, boardList);
  } else {
    postDetail.style.display = 'block';
  }
  
  // 현재 섹션과 카테고리 가져오기
  const urlParams = new URLSearchParams(window.location.search);
  const section = urlParams.get('section') || 'common';
  const category = urlParams.get('category') || 'all';
  
  // 섹션명과 카테고리명 가져오기
  const sectionName = getSectionName(section);
  let categoryText = '';
  const categories = getSectionCategories(section);
  const categoryObj = categories.find(c => c.value === category);
  if (categoryObj) {
    categoryText = categoryObj.text;
  }
  
  // 게시글 제목 생성
  let postTitle = `게시글 #${postId} 제목 (예시)`;
  if (section !== 'common') {
    postTitle = `[${sectionName}${categoryText !== '전체' ? ' - ' + categoryText : ''}] 게시글 #${postId} 제목 (예시)`;
  }
  
  // 임시 데이터로 게시글 상세 내용 표시 (실제로는 서버에서 받아옴)
  postDetail.innerHTML = `
    <div class="post-header">
      <h3 class="post-title">${postTitle}</h3>
      <div class="post-info">
        <span class="post-author">작성자: 홍길동</span>
        <span class="post-date">2025.05.10</span>
        <span class="post-views">조회: 123</span>
      </div>
    </div>
    <div class="post-content">
      <p>이 부분은 게시글 #${postId}의 상세 내용입니다.</p>
      <p>실제 구현에서는 서버에서 받아온 데이터를 표시합니다.</p>
      ${section !== 'common' ? `<p>이 게시글은 ${sectionName}${categoryText !== '전체' ? ' - ' + categoryText : ''} 섹션에 속한 게시글입니다.</p>` : ''}
    </div>
    <div class="post-actions">
      <button onclick="backToList()" class="btn-back">목록으로</button>
    </div>
  `;
}

// 목록으로 돌아가기
function backToList() {
  // URL에서 post_id와 view 파라미터 제거
  const url = new URL(window.location);
  url.searchParams.delete('post_id');
  url.searchParams.delete('view');
  window.history.pushState({}, '', url);
  
  // 게시글 상세 숨기고 목록 표시
  const postDetail = document.querySelector('.post-detail');
  const boardList = document.querySelector('.board-list');
  
  if (postDetail) {
    postDetail.style.display = 'none';
  }
  
  if (boardList) {
    boardList.style.display = 'block';
  }
}

// 페이지 로드 시 URL 파라미터 처리
window.addEventListener('load', function() {
  const urlParams = new URLSearchParams(window.location.search);
  const view = urlParams.get('view');
  const postId = urlParams.get('post_id');
  
  // 상세 보기 모드인 경우
  if (view === 'detail' && postId) {
    fetchPostDetail(postId);
  }
});

// 뒤로가기/앞으로가기 처리
window.addEventListener('popstate', function() {
  const urlParams = new URLSearchParams(window.location.search);
  const category = urlParams.get('category') || 'all';
  const section = urlParams.get('section') || 'common';
  const view = urlParams.get('view');
  const postId = urlParams.get('post_id');
  const page = parseInt(urlParams.get('page') || '1');
  
  // 특별 카테고리 처리
  handleSpecialCategories(category);
  
  // 섹션에 따라 카테고리 버튼 업데이트
  updateCategoryButtonsBySection(section);
  
  // 카테고리 버튼 상태 업데이트
  const categoryButtons = document.querySelectorAll('.category-btn');
  categoryButtons.forEach(button => {
    const buttonCategory = button.getAttribute('data-category');
    if (buttonCategory === category) {
      button.classList.add('active');
    } else {
      button.classList.remove('active');
    }
  });
  
  // 게시판 목록 및 제목 업데이트
  updateBoardList(category, section, page);
  updateBoardTitle(category, section);
  
  // 상세 보기 모드인 경우
  if (view === 'detail' && postId) {
    fetchPostDetail(postId);
  } else {
    // 목록 모드인 경우
    const postDetail = document.querySelector('.post-detail');
    const boardList = document.querySelector('.board-list');
    
    if (postDetail) {
      postDetail.style.display = 'none';
    }
    
    if (boardList) {
      boardList.style.display = 'block';
    }
  }
});

// KBO 섹션 테스트 데이터 생성 (시뮬레이션용 - 나중에 서버에서 데이터를 받아와야 함)
function generateTestDataForKBO() {
  // 이 함수는 구현이 되어 있지 않지만, 서버 연동 시 사용할 수 있는 함수입니다.
  // 실제 구현에서는 서버에서 데이터를 받아와 처리합니다.
}

// 글쓰기 버튼 이벤트 리스너 등록
function initWriteButton() {
  const writeBtn = document.querySelector('.write-btn');
  if (!writeBtn) return;
  
  // 글쓰기 버튼 클릭 시 글쓰기 폼 열기
  writeBtn.addEventListener('click', function(e) {
    e.preventDefault();
    
    // 현재 섹션과 카테고리 정보 가져오기
    const urlParams = new URLSearchParams(window.location.search);
    const section = urlParams.get('section') || 'common';
    const category = urlParams.get('category') || 'all';
    
    // 글쓰기 폼에 섹션과 카테고리 정보 표시
    updateWriteFormCategory(section, category);
    
    // 글쓰기 폼 열기
    openWriteForm();
  });
  
  // 글쓰기 폼 닫기 버튼
  const closeWriteFormBtn = document.getElementById('close-write-form');
  if (closeWriteFormBtn) {
    closeWriteFormBtn.addEventListener('click', closeWriteForm);
  }
  
  // 취소 버튼
  const cancelWriteBtn = document.getElementById('cancel-write');
  if (cancelWriteBtn) {
    cancelWriteBtn.addEventListener('click', closeWriteForm);
  }
  
  // 폼 제출
  const postWriteForm = document.getElementById('post-write-form');
  if (postWriteForm) {
    postWriteForm.addEventListener('submit', function(e) {
      e.preventDefault();
      submitPost();
    });
  }
}

// 글쓰기 폼 카테고리 정보 업데이트
function updateWriteFormCategory(section, category) {
  const sectionNameElem = document.getElementById('write-section-name');
  const categoryNameElem = document.getElementById('write-category-name');
  
  if (sectionNameElem && categoryNameElem) {
    // 섹션 이름 설정
    let sectionName = getSectionName(section);
    sectionNameElem.textContent = sectionName;
    
    // 카테고리 이름 설정
    let categoryName = '';
    if (section === 'common') {
      // 공통 섹션의 카테고리
      switch(category) {
        case 'all': categoryName = '전체글'; break;
        case 'free': categoryName = '자유게시판'; break;
        case 'notice': categoryName = '공지사항'; break;
        case 'review': categoryName = '구매후기'; break;
        case 'tips': categoryName = '야구팁'; break;
        case 'faq': categoryName = 'FAQ'; break;
        default: categoryName = '전체글';
      }
    } else {
      // 특별 섹션의 카테고리
      const categories = getSectionCategories(section);
      const categoryObj = categories.find(c => c.value === category);
      categoryName = categoryObj ? categoryObj.text : '전체';
    }
    
    categoryNameElem.textContent = categoryName;
  }
}

// 글쓰기 폼 열기
function openWriteForm() {
  const writeFormOverlay = document.querySelector('.write-form-overlay');
  if (writeFormOverlay) {
    writeFormOverlay.classList.add('show');
    
    // 폼 초기화
    const postTitleInput = document.getElementById('post-title');
    const postContentInput = document.getElementById('post-content');
    const postFileInput = document.getElementById('post-file');
    
    if (postTitleInput) postTitleInput.value = '';
    if (postContentInput) postContentInput.value = '';
    if (postFileInput) postFileInput.value = '';
    
    // 제목 입력 필드에 포커스
    if (postTitleInput) {
      setTimeout(() => {
        postTitleInput.focus();
      }, 300);
    }
  }
}

// 글쓰기 폼 닫기
function closeWriteForm() {
  const writeFormOverlay = document.querySelector('.write-form-overlay');
  if (writeFormOverlay) {
    writeFormOverlay.classList.remove('show');
  }
}

// 게시글 작성 완료 처리
function submitPost() {
  // 폼 데이터 가져오기
  const titleInput = document.getElementById('post-title');
  const contentInput = document.getElementById('post-content');
  
  if (!titleInput || !contentInput) return;
  
  const title = titleInput.value.trim();
  const content = contentInput.value.trim();
  
  if (!title || !content) {
    alert('제목과 내용을 모두 입력해주세요.');
    return;
  }
  
  // 현재 섹션과 카테고리 정보 가져오기
  const urlParams = new URLSearchParams(window.location.search);
  const section = urlParams.get('section') || 'common';
  const category = urlParams.get('category') || 'all';
  
  // 실제 서비스에서는 서버에 데이터 전송
  // 현재는 프론트엔드에서 시뮬레이션
  
  // 게시글 ID 생성 (실제로는 서버에서 생성)
  const postId = 'post_' + Date.now();
  
  // 현재 시간 포맷팅
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const formattedDate = `${year}.${month}.${day}`;
  
  // 작성자 (실제로는 로그인한 사용자 정보 사용)
  const author = '사용자123';
  
  // 게시글 추가
  addNewPostToList(postId, title, section, category, author, formattedDate, 0);
  
  // 글쓰기 폼 닫기
  closeWriteForm();
  
  // 성공 메시지
  alert('게시글이 등록되었습니다.');
}

// 게시글 목록에 새 게시글 추가
function addNewPostToList(postId, title, section, category, author, date, views) {
  // 테이블 본문 가져오기
  const tbody = document.querySelector('.board-table tbody');
  if (!tbody) return;
  
  // 게시물 없음 메시지 숨기기
  const noPostsRow = document.querySelector('.no-posts-row');
  if (noPostsRow) {
    noPostsRow.style.display = 'none';
  }
  
  // 카테고리 텍스트 가져오기
  let categoryText = '';
  if (section === 'common') {
    // 일반 카테고리
    switch(category) {
      case 'free': categoryText = '자유'; break;
      case 'notice': categoryText = '공지'; break;
      case 'review': categoryText = '구매후기'; break;
      case 'tips': categoryText = '야구팁'; break;
      case 'faq': categoryText = 'FAQ'; break;
      default: categoryText = '기타';
    }
  } else if (section === 'kbo') {
    // KBO 팀 카테고리
    const categories = getSectionCategories('kbo');
    const categoryObj = categories.find(c => c.value === category);
    categoryText = categoryObj ? categoryObj.text : 'KBO';
  } else {
    // 기타 섹션 카테고리
    const categories = getSectionCategories(section);
    const categoryObj = categories.find(c => c.value === category);
    categoryText = categoryObj ? categoryObj.text : '기타';
  }
  
  // 새 행 생성
  const newRow = document.createElement('tr');
  newRow.className = 'new-post';
  newRow.dataset.section = section;
  newRow.dataset.category = category;
  
  // 행 번호 계산 (공지사항 제외)
  const regularRows = document.querySelectorAll('.board-table tbody tr:not(.notice):not(.no-posts-row)');
  const newRowNum = regularRows.length + 1;
  
  // 새 행 내용 채우기
  newRow.innerHTML = `
    <td class="num">${newRowNum}</td>
    <td class="category">${categoryText}</td>
    <td class="title"><a href="javascript:void(0);" onclick="viewPost('${postId}', '${category}')">${title}</a> <span class="new-tag">NEW</span></td>
    <td class="author">${author}</td>
    <td class="date">${date}</td>
    <td class="views">${views}</td>
  `;
  
  // 테이블에 새 행 추가 (공지사항 다음에)
  const noticeRows = document.querySelectorAll('.board-table tbody tr.notice');
  if (noticeRows.length > 0) {
    const lastNotice = noticeRows[noticeRows.length - 1];
    lastNotice.insertAdjacentElement('afterend', newRow);
  } else {
    tbody.prepend(newRow);
  }
  
  // 현재 페이지 재로드
  const urlParams = new URLSearchParams(window.location.search);
  const currentPage = parseInt(urlParams.get('page') || '1');
  updateBoardList(category, section, currentPage);
} 